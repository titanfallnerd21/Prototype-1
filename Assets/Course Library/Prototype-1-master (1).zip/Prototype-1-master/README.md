# Prototype 1: Player Control

Starter assets for Prototype 1 from the Unity [Create With Code](https://learn.unity.com/course/create-with-code) curriculum.

To get started:

* Fork (skip this step if you don't have a GitHub account) this repository.
* Clone to your development machine.
* Launch Unity Hub and Add the cloned repository.
* Pick up the tutorial at Lesson 1.1 step 4.

Assignments, for Canvas, are in the [Create With Code](https://github.com/DouglasUrner/Create-With-Code.git) repository.
